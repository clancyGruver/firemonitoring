export default function () {
    return [
      {
        title: 'Районы',
        to: {
            name: 'raions',
        },
        htmlBefore: '<i class="material-icons">public</i>',
        htmlAfter: '',
      },
      {
        title: 'Объекты',
        to: {
            name: 'objects',
        },
        htmlBefore: '<i class="material-icons">domain</i>',
        htmlAfter: '',
      }
    ];
}
