<template>
  <d-container fluid>
    <d-row>
      <!-- Main Sidebar -->
      <main-sidebar :items="sidebarItems" />

      <d-col class="main-content offset-lg-2 offset-md-3 p-0" tag="main" lg="10" md="9" sm="12">

        <!-- Main Navbar -->
        <main-navbar />

        <!-- Content -->
        <slot />

        <!-- Main Footer -->
        <!--main-footer /-->
      </d-col>

    </d-row>
  </d-container>
</template>

<script>
import getSidebarItems from '../../admin-data/sidebar-nav-items';

// Main layout components
import MainNavbar from '../admin-layout/MainNavbar/MainNavbar.vue';
import MainSidebar from '../admin-layout/MainSidebar/MainSidebar.vue';
//import MainFooter from '../admin-layout/MainFooter/MainFooter.vue';

export default {
  name: 'analytics',
  components: {
    MainNavbar,
    MainSidebar,
//    MainFooter,
  },
  data() {
    return {
      sidebarItems: getSidebarItems(),
    };
  },
};
</script>

