@extends('layouts.app')

@section('content')
    @include('layouts.headers.cards')
    
@endsection

@push('js')
@endpush